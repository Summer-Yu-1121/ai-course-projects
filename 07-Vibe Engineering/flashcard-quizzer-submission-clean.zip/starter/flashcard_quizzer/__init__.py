"""Flashcard Quizzer application package."""
